# Setup MySQL Database for Last Drop
# This script creates the database and tables

Write-Host "=== Last Drop Database Setup ===" -ForegroundColor Cyan
Write-Host ""

# Create setup SQL
$setupSQL = @"
CREATE DATABASE IF NOT EXISTS lastdrop;
CREATE USER IF NOT EXISTS 'lastdrop_user'@'localhost' IDENTIFIED BY 'Lastdrop1!db';
GRANT ALL PRIVILEGES ON lastdrop.* TO 'lastdrop_user'@'localhost';
FLUSH PRIVILEGES;
"@

# Write SQL to temp file
$setupSQL | Out-File -FilePath ".\temp_setup.sql" -Encoding ASCII

# Upload and execute
Write-Host "Uploading setup SQL..." -ForegroundColor Yellow
scp ".\temp_setup.sql" lastdrop:/tmp/setup.sql

Write-Host "Creating database and user..." -ForegroundColor Yellow
$password = "Lastdrop1!"
$command = "echo '$password' | sudo -S mysql < /tmp/setup.sql"
ssh lastdrop $command

Write-Host "Uploading schema..." -ForegroundColor Yellow  
scp "website\api\database_schema.sql" lastdrop:/tmp/schema.sql

Write-Host "Creating tables..." -ForegroundColor Yellow
$command2 = "echo '$password' | sudo -S mysql lastdrop < /tmp/schema.sql"
ssh lastdrop $command2

Write-Host ""
Write-Host "Verifying setup..." -ForegroundColor Yellow
ssh lastdrop "mysql -u lastdrop_user -p'Lastdrop1!db' lastdrop -e 'SHOW TABLES;'"

Write-Host ""
Write-Host "=== Setup Complete ===" -ForegroundColor Green

# Cleanup
Remove-Item ".\temp_setup.sql" -ErrorAction SilentlyContinue
