package com.example.lastdrop

data class ChanceCard(
    val number: Int,
    val description: String,
    val effect: Int
)
