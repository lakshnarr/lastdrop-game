package com.example.lastdrop.game

import com.example.lastdrop.GameEngine
import com.example.lastdrop.GameEngine.*

/**
 * GameStateManager - Manages current game state and turn processing
 * Separates game logic from UI concerns for better testability
 */
class GameStateManager(private val gameEngine: GameEngine) {
    
    data class PlayerData(
        var name: String,
        var profileId: String?,
        var color: String,
        var position: Int = 1,
        var score: Int = 10,
        var isAlive: Boolean = true,
        var lapsCompleted: Int = 0
    )
    
    data class GameState(
        val players: List<PlayerData>,
        val currentPlayerIndex: Int,
        val isGameOver: Boolean,
        val winner: PlayerData?
    )
    
    private val players = mutableListOf<PlayerData>()
    private var currentPlayerIndex = 0
    private var isGameActive = false
    
    fun initializeGame(
        playerNames: List<String>,
        playerColors: List<String>,
        profileIds: List<String?>? = null
    ) {
        players.clear()
        playerNames.forEachIndexed { index, name ->
            players.add(PlayerData(
                name = name,
                profileId = profileIds?.getOrNull(index),
                color = playerColors[index],
                position = 1,
                score = 10,
                isAlive = true,
                lapsCompleted = 0
            ))
        }
        currentPlayerIndex = 0
        isGameActive = true
    }
    
    fun processRoll(diceValue: Int): TurnResult {
        if (!isGameActive || players.isEmpty()) {
            throw IllegalStateException("Game not initialized")
        }
        
        val currentPlayer = players[currentPlayerIndex]
        if (!currentPlayer.isAlive) {
            throw IllegalStateException("Current player is eliminated")
        }
        
        val turnResult = gameEngine.processTurn(currentPlayer.position, diceValue)
        
        // Update player state
        currentPlayer.position = turnResult.newPosition
        currentPlayer.score += turnResult.scoreChange
        
        // Check lap completion
        if (turnResult.newPosition < currentPlayer.position - diceValue) {
            currentPlayer.lapsCompleted++
        }
        
        // Check elimination
        if (currentPlayer.score <= 0) {
            currentPlayer.isAlive = false
            currentPlayer.score = 0
        }
        
        return TurnResult(
            tile = turnResult.tile,
            newPosition = turnResult.newPosition,
            scoreChange = turnResult.scoreChange,
            chanceCard = turnResult.chanceCard,
            playerData = currentPlayer
        )
    }
    
    fun advanceToNextPlayer() {
        if (players.isEmpty()) return
        
        // Find next alive player
        val startIndex = currentPlayerIndex
        do {
            currentPlayerIndex = (currentPlayerIndex + 1) % players.size
            if (players[currentPlayerIndex].isAlive) {
                break
            }
        } while (currentPlayerIndex != startIndex)
        
        // Check if game is over (only 1 or 0 alive)
        val alivePlayers = players.count { it.isAlive }
        if (alivePlayers <= 1) {
            isGameActive = false
        }
    }
    
    fun undoLastMove(previousPosition: Int, previousScore: Int) {
        if (players.isEmpty()) return
        val currentPlayer = players[currentPlayerIndex]
        currentPlayer.position = previousPosition
        currentPlayer.score = previousScore
        currentPlayer.isAlive = previousScore > 0
    }
    
    fun getCurrentPlayer(): PlayerData? {
        return players.getOrNull(currentPlayerIndex)
    }
    
    fun getAllPlayers(): List<PlayerData> = players.toList()
    
    fun getGameState(): GameState {
        val alivePlayers = players.count { it.isAlive }
        val winner = if (alivePlayers == 1) {
            players.firstOrNull { it.isAlive }
        } else {
            null
        }
        
        return GameState(
            players = players.toList(),
            currentPlayerIndex = currentPlayerIndex,
            isGameOver = !isGameActive,
            winner = winner
        )
    }
    
    fun resetGame() {
        players.forEach { player ->
            player.position = 1
            player.score = 10
            player.isAlive = true
            player.lapsCompleted = 0
        }
        currentPlayerIndex = 0
        isGameActive = true
    }
    
    fun getPlayerByIndex(index: Int): PlayerData? = players.getOrNull(index)
    
    fun getPlayerCount(): Int = players.size
    
    fun getAlivePlayerCount(): Int = players.count { it.isAlive }
    
    fun isGameActive(): Boolean = isGameActive
    
    data class TurnResult(
        val tile: Tile,
        val newPosition: Int,
        val scoreChange: Int,
        val chanceCard: ChanceCard?,
        val playerData: PlayerData
    )
}
