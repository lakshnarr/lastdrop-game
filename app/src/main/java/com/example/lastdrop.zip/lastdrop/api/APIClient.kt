package com.example.lastdrop.api

import android.content.Context
import android.util.Log
import com.example.lastdrop.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * APIClient - Handles all server communication for live display and analytics
 * Encapsulates HTTP requests, error handling, and JSON serialization
 */
class APIClient(private val context: Context) {
    
    private val tag = "APIClient"
    private val baseUrl = "https://lastdrop.earth/api"
    private val apiKey = BuildConfig.API_KEY
    
    data class PlayerState(
        val name: String,
        val score: Int,
        val position: Int,
        val color: String,
        val alive: Boolean
    )
    
    data class LivePushPayload(
        val sessionId: String,
        val players: List<PlayerState>,
        val currentPlayer: Int,
        val dice1: Int?,
        val dice2: Int?,
        val avg: Int?,
        val coinPlaced: Boolean,
        val eventMessage: String?
    )
    
    /**
     * Push complete game state to server for live.html display
     */
    suspend fun pushLiveState(payload: LivePushPayload): Result<String> = withContext(Dispatchers.IO) {
        try {
            val json = JSONObject().apply {
                put("apiKey", apiKey)
                put("sessionId", payload.sessionId)
                put("currentPlayer", payload.currentPlayer)
                put("players", JSONArray().apply {
                    payload.players.forEach { player ->
                        put(JSONObject().apply {
                            put("name", player.name)
                            put("score", player.score)
                            put("position", player.position)
                            put("color", player.color)
                            put("alive", player.alive)
                        })
                    }
                })
                put("lastEvent", JSONObject().apply {
                    payload.dice1?.let { put("dice1", it) }
                    payload.dice2?.let { put("dice2", it) }
                    payload.avg?.let { put("avg", it) }
                    put("coinPlaced", payload.coinPlaced)
                    payload.eventMessage?.let { put("message", it) }
                })
            }
            
            val response = postJson("$baseUrl/live_push.php", json)
            Result.success(response)
        } catch (e: Exception) {
            Log.e(tag, "Live push failed", e)
            Result.failure(e)
        }
    }
    
    /**
     * Log roll event to database
     */
    suspend fun logRoll(
        gameId: String,
        playerId: String,
        dice1: Int,
        dice2: Int?,
        avg: Int
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val json = JSONObject().apply {
                put("apiKey", apiKey)
                put("gameId", gameId)
                put("playerId", playerId)
                put("dice1", dice1)
                dice2?.let { put("dice2", it) }
                put("avg", avg)
                put("timestamp", System.currentTimeMillis())
            }
            
            val response = postJson("$baseUrl/roll.php", json)
            Result.success(response)
        } catch (e: Exception) {
            Log.e(tag, "Roll logging failed", e)
            Result.failure(e)
        }
    }
    
    /**
     * Fetch current game state from server
     */
    suspend fun fetchLiveState(sessionId: String): Result<JSONObject> = withContext(Dispatchers.IO) {
        try {
            val url = "$baseUrl/live_state.php?sessionId=$sessionId&apiKey=$apiKey"
            val response = getJson(url)
            Result.success(response)
        } catch (e: Exception) {
            Log.e(tag, "Fetch state failed", e)
            Result.failure(e)
        }
    }
    
    /**
     * Get list of active sessions for multi-board
     */
    suspend fun getActiveSessions(): Result<JSONArray> = withContext(Dispatchers.IO) {
        try {
            val url = "$baseUrl/session_list.php?apiKey=$apiKey"
            val response = getJson(url)
            val sessions = response.optJSONArray("sessions") ?: JSONArray()
            Result.success(sessions)
        } catch (e: Exception) {
            Log.e(tag, "Fetch sessions failed", e)
            Result.failure(e)
        }
    }
    
    /**
     * Register ESP32 board with server
     */
    suspend fun registerBoard(
        esp32Id: String,
        friendlyName: String,
        qrCodeUrl: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val json = JSONObject().apply {
                put("apiKey", apiKey)
                put("esp32Id", esp32Id)
                put("friendlyName", friendlyName)
                put("qrCodeUrl", qrCodeUrl)
                put("timestamp", System.currentTimeMillis())
            }
            
            val response = postJson("$baseUrl/register_board.php", json)
            Result.success(response)
        } catch (e: Exception) {
            Log.e(tag, "Board registration failed", e)
            Result.failure(e)
        }
    }
    
    private fun postJson(urlString: String, json: JSONObject): String {
        val url = URL(urlString)
        val connection = url.openConnection() as HttpURLConnection
        
        return try {
            connection.apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json")
                doOutput = true
                connectTimeout = 10000
                readTimeout = 10000
            }
            
            OutputStreamWriter(connection.outputStream).use { writer ->
                writer.write(json.toString())
                writer.flush()
            }
            
            val responseCode = connection.responseCode
            if (responseCode !in 200..299) {
                throw Exception("HTTP $responseCode: ${connection.responseMessage}")
            }
            
            connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }
    
    private fun getJson(urlString: String): JSONObject {
        val url = URL(urlString)
        val connection = url.openConnection() as HttpURLConnection
        
        return try {
            connection.apply {
                requestMethod = "GET"
                connectTimeout = 10000
                readTimeout = 10000
            }
            
            val responseCode = connection.responseCode
            if (responseCode !in 200..299) {
                throw Exception("HTTP $responseCode: ${connection.responseMessage}")
            }
            
            val response = connection.inputStream.bufferedReader().use { it.readText() }
            JSONObject(response)
        } finally {
            connection.disconnect()
        }
    }
}
