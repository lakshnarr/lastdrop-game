package com.example.lastdrop.dice

import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import org.sample.godicesdklib.GoDiceSDK
import java.util.*

/**
 * DiceManager - Handles all GoDice BLE connection and communication
 * Separated from MainActivity for better testability and reusability
 */
class DiceManager(
    private val context: Context,
    private val listener: DiceEventListener
) : GoDiceSDK.Listener {
    
    private val tag = "DiceManager"
    private val handler = Handler(Looper.getMainLooper())
    
    private var bluetoothAdapter: BluetoothAdapter? = null
    private var isScanning = false
    private var scanCallback: ScanCallback? = null
    
    private val dices = HashMap<String, Dice>()
    private val diceIds = LinkedList<String>()
    private val diceColorMap = HashMap<Int, String>()
    private val diceResults = HashMap<Int, Int>()
    private val diceRollingStatus = HashMap<Int, Boolean>()
    private val diceBatteryLevels = HashMap<Int, Int>()
    
    var playWithTwoDice: Boolean = false
    var isDiceRolling: Boolean = false
    var diceConnected: Boolean = false
    
    // Last roll data for API
    var lastDice1: Int? = null
    var lastDice2: Int? = null
    var lastAvg: Int? = null
    
    interface DiceEventListener {
        fun onDiceConnected(count: Int)
        fun onDiceDisconnected()
        fun onDiceRolling(diceCount: Int, totalDice: Int)
        fun onDiceStable(dice1: Int, dice2: Int?, avg: Int, modeTwoDice: Boolean)
        fun onDiceColor(diceId: Int, colorName: String)
        fun onBatteryUpdate(levels: Map<Int, Int>)
        fun onScanStatusChanged(isScanning: Boolean, message: String)
    }
    
    fun initialize(adapter: BluetoothAdapter?) {
        bluetoothAdapter = adapter
        GoDiceSDK.listener = this
    }
    
    fun startScan() {
        val adapter = bluetoothAdapter ?: run {
            listener.onScanStatusChanged(false, "Bluetooth adapter not available")
            return
        }
        
        val scanner = adapter.bluetoothLeScanner ?: run {
            listener.onScanStatusChanged(false, "BLE scanner not available")
            return
        }
        
        if (isScanning) {
            listener.onScanStatusChanged(true, "Already scanning")
            return
        }
        
        val filters = LinkedList<ScanFilter>().apply {
            add(ScanFilter.Builder()
                .setServiceUuid(android.os.ParcelUuid(Dice.serviceUUID))
                .build())
        }
        
        val scanSettings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()
        
        scanCallback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                handleScanResult(result)
            }
            
            override fun onBatchScanResults(results: MutableList<ScanResult>) {
                results.forEach { handleScanResult(it) }
            }
            
            override fun onScanFailed(errorCode: Int) {
                isScanning = false
                listener.onScanStatusChanged(false, "Scan failed: $errorCode")
            }
        }
        
        isScanning = true
        scanner.startScan(filters, scanSettings, scanCallback)
        listener.onScanStatusChanged(true, if (playWithTwoDice) "Scanning for 2 GoDice…" else "Scanning for GoDice…")
        
        // Auto-stop after 15 seconds
        handler.postDelayed({
            if (isScanning) {
                stopScan()
                listener.onScanStatusChanged(false, "Scan timeout. No GoDice found.")
            }
        }, 15000)
    }
    
    fun stopScan() {
        if (!isScanning) return
        bluetoothAdapter?.bluetoothLeScanner?.stopScan(scanCallback)
        isScanning = false
    }
    
    fun disconnectAll() {
        stopScan()
        dices.values.forEach { it.gatt?.disconnect(); it.gatt?.close() }
        dices.clear()
        diceIds.clear()
        diceResults.clear()
        diceBatteryLevels.clear()
        diceColorMap.clear()
        diceRollingStatus.clear()
        diceConnected = false
        listener.onDiceDisconnected()
    }
    
    private fun handleScanResult(result: ScanResult) {
        val device = result.device ?: return
        val name = device.name ?: return
        
        if (!name.contains("GoDice")) return
        if (dices.containsKey(device.address)) return
        
        var diceId = diceIds.indexOf(device.address)
        if (diceId < 0) {
            diceId = diceIds.size
            diceIds.add(device.address)
        }
        
        val dice = Dice(diceId, device)
        dices[device.address] = dice
        
        // LED blink + queries
        dice.scheduleWrite(GoDiceSDK.openLedsPacket(0xff0000, 0x00ff00))
        Timer().schedule(object : TimerTask() {
            override fun run() {
                dice.scheduleWrite(GoDiceSDK.closeToggleLedsPacket())
            }
        }, 3000)
        
        dice.scheduleWrite(GoDiceSDK.getColorPacket())
        dice.scheduleWrite(GoDiceSDK.getChargeLevelPacket())
        
        // Stop scanning if we have enough dice
        val neededDice = if (playWithTwoDice) 2 else 1
        if (dices.size >= neededDice) {
            stopScan()
        }
        
        dice.gatt = device.connectGatt(context, true, createGattCallback(dice))
    }
    
    private fun createGattCallback(dice: Dice) = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt?, status: Int, newState: Int) {
            when (newState) {
                BluetoothProfile.STATE_CONNECTED -> {
                    diceConnected = true
                    listener.onDiceConnected(dices.size)
                    dice.onConnected()
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    diceConnected = false
                    listener.onDiceDisconnected()
                }
            }
        }
        
        override fun onServicesDiscovered(gatt: BluetoothGatt?, status: Int) {
            dice.onServicesDiscovered()
        }
        
        @Deprecated("Use onCharacteristicChanged(gatt, characteristic, value) instead")
        override fun onCharacteristicChanged(
            gatt: BluetoothGatt?,
            characteristic: BluetoothGattCharacteristic?
        ) {
            dice.onEvent()
        }
        
        override fun onDescriptorWrite(
            gatt: BluetoothGatt?,
            descriptor: BluetoothGattDescriptor?,
            status: Int
        ) {
            dice.nextWrite()
        }
        
        override fun onCharacteristicWrite(
            gatt: BluetoothGatt?,
            characteristic: BluetoothGattCharacteristic?,
            status: Int
        ) {
            dice.nextWrite()
        }
    }
    
    // GoDiceSDK.Listener implementation
    override fun onDiceColor(diceId: Int, color: Int) {
        val colorName = when (color) {
            GoDiceSDK.DICE_BLACK -> "black"
            GoDiceSDK.DICE_RED -> "red"
            GoDiceSDK.DICE_GREEN -> "green"
            GoDiceSDK.DICE_BLUE -> "blue"
            GoDiceSDK.DICE_YELLOW -> "yellow"
            GoDiceSDK.DICE_ORANGE -> "orange"
            else -> "red"
        }
        diceColorMap[diceId] = colorName
        listener.onDiceColor(diceId, colorName)
    }
    
    override fun onDiceRoll(diceId: Int, number: Int) {
        diceRollingStatus[diceId] = true
        if (!isDiceRolling) {
            isDiceRolling = true
        }
        
        val rollingCount = diceRollingStatus.values.count { it }
        val totalDice = if (playWithTwoDice) 2 else 1
        listener.onDiceRolling(rollingCount, totalDice)
    }
    
    override fun onDiceStable(diceId: Int, number: Int) {
        diceRollingStatus[diceId] = false
        val anyDiceRolling = diceRollingStatus.values.any { it }
        if (!anyDiceRolling) {
            isDiceRolling = false
        }
        
        if (!playWithTwoDice) {
            // Single die mode
            lastDice1 = number
            lastDice2 = null
            lastAvg = number
            listener.onDiceStable(number, null, number, false)
        } else {
            // Two dice mode
            diceResults[diceId] = number
            
            val sortedIds = diceResults.keys.sorted()
            val d1Id = sortedIds[0]
            val d2Id = sortedIds.getOrNull(1)
            val v1 = diceResults[d1Id] ?: return
            val v2 = d2Id?.let { diceResults[it] }
            
            lastDice1 = v1
            lastDice2 = v2
            lastAvg = v2?.let { ((v1 + it) / 2.0).toInt() }
            
            if (diceResults.size < 2) {
                // First die stable, waiting for second
                return
            }
            
            // Both dice stable
            val v1Final = lastDice1!!
            val v2Final = lastDice2!!
            val avg = ((v1Final + v2Final) / 2.0).toInt()
            lastAvg = avg
            
            diceResults.clear()
            listener.onDiceStable(v1Final, v2Final, avg, true)
        }
    }
    
    override fun onDiceChargeLevel(diceId: Int, level: Int) {
        diceBatteryLevels[diceId] = level
        listener.onBatteryUpdate(diceBatteryLevels.toMap())
    }
    
    override fun onDiceChargingStateChanged(diceId: Int, charging: Boolean) {
        Log.d(tag, "Dice $diceId ${if (charging) "charging" else "not charging"}")
    }
    
    fun getBatteryLevels() = diceBatteryLevels.toMap()
    fun getDiceColors() = diceColorMap.toMap()
}
