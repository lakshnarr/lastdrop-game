package com.example.lastdrop.board

import android.bluetooth.*
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.example.lastdrop.GameEngine
import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.util.*

/**
 * ESP32Manager - Handles all ESP32 BLE communication for physical board
 * Encapsulates Nordic UART protocol and JSON command/event handling
 */
class ESP32Manager(
    private val context: Context,
    private val listener: ESP32EventListener
) {
    private val tag = "ESP32Manager"
    private val handler = Handler(Looper.getMainLooper())
    
    // Nordic UART UUIDs
    private val SERVICE_UUID = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e")
    private val RX_CHAR_UUID = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e")
    private val TX_CHAR_UUID = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e")
    private val CCCD_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    
    private var bluetoothGatt: BluetoothGatt? = null
    private var rxCharacteristic: BluetoothGattCharacteristic? = null
    private var txCharacteristic: BluetoothGattCharacteristic? = null
    
    private var isConnected = false
    private var currentPlayerIndex = 0
    
    // Command queue for BLE writes
    private val writeQueue = LinkedList<ByteArray>()
    private var isWriting = false
    
    interface ESP32EventListener {
        fun onConnected()
        fun onDisconnected()
        fun onCoinPlaced(tile: Int, playerId: Int)
        fun onMisplacement(expectedTile: Int, actualTile: Int)
        fun onUndoComplete()
        fun onConfigComplete()
        fun onReady()
        fun onError(message: String)
    }
    
    fun connect(device: BluetoothDevice) {
        bluetoothGatt = device.connectGatt(context, false, gattCallback)
    }
    
    fun disconnect() {
        bluetoothGatt?.disconnect()
        bluetoothGatt?.close()
        bluetoothGatt = null
        isConnected = false
        writeQueue.clear()
        isWriting = false
        listener.onDisconnected()
    }
    
    fun sendRollCommand(playerId: Int, diceValue: Int) {
        val json = JSONObject().apply {
            put("command", "roll")
            put("playerId", playerId)
            put("diceValue", diceValue)
        }
        sendCommand(json)
    }
    
    fun sendUndoCommand() {
        val json = JSONObject().apply {
            put("command", "undo")
        }
        sendCommand(json)
    }
    
    fun sendResetCommand() {
        val json = JSONObject().apply {
            put("command", "reset")
        }
        sendCommand(json)
    }
    
    fun sendConfigCommand(playerCount: Int, colors: List<String>) {
        val json = JSONObject().apply {
            put("command", "config")
            put("playerCount", playerCount)
            put("colors", JSONArray(colors))
        }
        sendCommand(json)
    }
    
    private fun sendCommand(json: JSONObject) {
        val data = json.toString().toByteArray(StandardCharsets.UTF_8)
        queueWrite(data)
    }
    
    private fun queueWrite(data: ByteArray) {
        writeQueue.add(data)
        processWriteQueue()
    }
    
    private fun processWriteQueue() {
        if (isWriting || writeQueue.isEmpty()) return
        if (!isConnected || rxCharacteristic == null) return
        
        isWriting = true
        val data = writeQueue.poll() ?: run {
            isWriting = false
            return
        }
        
        rxCharacteristic?.value = data
        bluetoothGatt?.writeCharacteristic(rxCharacteristic)
    }
    
    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt?, status: Int, newState: Int) {
            when (newState) {
                BluetoothProfile.STATE_CONNECTED -> {
                    Log.d(tag, "ESP32 connected, discovering services")
                    gatt?.discoverServices()
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    isConnected = false
                    listener.onDisconnected()
                }
            }
        }
        
        override fun onServicesDiscovered(gatt: BluetoothGatt?, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                listener.onError("Service discovery failed")
                return
            }
            
            val service = gatt?.getService(SERVICE_UUID) ?: run {
                listener.onError("Nordic UART service not found")
                return
            }
            
            rxCharacteristic = service.getCharacteristic(RX_CHAR_UUID)
            txCharacteristic = service.getCharacteristic(TX_CHAR_UUID)
            
            if (rxCharacteristic == null || txCharacteristic == null) {
                listener.onError("Required characteristics not found")
                return
            }
            
            // Enable notifications on TX characteristic
            gatt.setCharacteristicNotification(txCharacteristic, true)
            val descriptor = txCharacteristic?.getDescriptor(CCCD_UUID)
            descriptor?.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            gatt.writeDescriptor(descriptor)
            
            isConnected = true
            listener.onConnected()
        }
        
        @Deprecated("Use onCharacteristicChanged(gatt, characteristic, value) instead")
        override fun onCharacteristicChanged(
            gatt: BluetoothGatt?,
            characteristic: BluetoothGattCharacteristic?
        ) {
            if (characteristic?.uuid != TX_CHAR_UUID) return
            
            val data = characteristic.value ?: return
            val message = String(data, StandardCharsets.UTF_8)
            
            try {
                val json = JSONObject(message)
                handleESP32Event(json)
            } catch (e: Exception) {
                Log.e(tag, "Failed to parse ESP32 message: $message", e)
            }
        }
        
        override fun onCharacteristicWrite(
            gatt: BluetoothGatt?,
            characteristic: BluetoothGattCharacteristic?,
            status: Int
        ) {
            isWriting = false
            if (status == BluetoothGatt.GATT_SUCCESS) {
                processWriteQueue()
            } else {
                Log.e(tag, "Write failed with status: $status")
                listener.onError("Write failed")
            }
        }
        
        override fun onDescriptorWrite(
            gatt: BluetoothGatt?,
            descriptor: BluetoothGattDescriptor?,
            status: Int
        ) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.d(tag, "Notifications enabled")
            }
        }
    }
    
    private fun handleESP32Event(json: JSONObject) {
        when (val event = json.optString("event")) {
            "coin_placed" -> {
                val tile = json.optInt("tile", -1)
                val playerId = json.optInt("playerId", -1)
                if (tile >= 1 && playerId >= 0) {
                    listener.onCoinPlaced(tile, playerId)
                }
            }
            "misplacement" -> {
                val expected = json.optInt("expectedTile", -1)
                val actual = json.optInt("actualTile", -1)
                if (expected >= 1 && actual >= 1) {
                    listener.onMisplacement(expected, actual)
                }
            }
            "undo_complete" -> {
                listener.onUndoComplete()
            }
            "config_complete" -> {
                listener.onConfigComplete()
            }
            "ready" -> {
                listener.onReady()
            }
            "error" -> {
                val msg = json.optString("message", "Unknown ESP32 error")
                listener.onError(msg)
            }
            else -> {
                Log.w(tag, "Unknown ESP32 event: $event")
            }
        }
    }
    
    fun isConnected() = isConnected
}
