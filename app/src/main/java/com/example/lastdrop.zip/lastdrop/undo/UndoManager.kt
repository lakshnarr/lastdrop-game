package com.example.lastdrop.undo

import android.os.Handler
import android.os.Looper
import kotlinx.coroutines.Job

/**
 * UndoManager - Handles undo confirmation window and state restoration
 * Separates undo logic from MainActivity for cleaner architecture
 */
class UndoManager(
    private val timeoutSeconds: Int = 5,
    private val listener: UndoListener
) {
    private val handler = Handler(Looper.getMainLooper())
    
    private var undoState: UndoState? = null
    private var timeoutRunnable: Runnable? = null
    private var isWindowActive = false
    
    interface UndoListener {
        fun onUndoWindowOpened(state: UndoState)
        fun onUndoWindowClosed()
        fun onUndoConfirmed(state: UndoState)
        fun onUndoTimedOut()
    }
    
    data class UndoState(
        val playerIndex: Int,
        val playerName: String,
        val previousPosition: Int,
        val previousScore: Int,
        val currentPosition: Int,
        val currentScore: Int,
        val diceValue: Int,
        val timestamp: Long = System.currentTimeMillis()
    )
    
    fun openUndoWindow(state: UndoState) {
        if (isWindowActive) {
            // Close existing window first
            closeUndoWindow()
        }
        
        undoState = state
        isWindowActive = true
        listener.onUndoWindowOpened(state)
        
        // Start timeout timer
        timeoutRunnable = Runnable {
            handleTimeout()
        }
        handler.postDelayed(timeoutRunnable!!, (timeoutSeconds * 1000).toLong())
    }
    
    fun confirmUndo(): Boolean {
        if (!isWindowActive || undoState == null) {
            return false
        }
        
        val state = undoState!!
        closeUndoWindow()
        listener.onUndoConfirmed(state)
        return true
    }
    
    fun closeUndoWindow() {
        if (!isWindowActive) return
        
        isWindowActive = false
        undoState = null
        
        // Cancel timeout
        timeoutRunnable?.let { handler.removeCallbacks(it) }
        timeoutRunnable = null
        
        listener.onUndoWindowClosed()
    }
    
    private fun handleTimeout() {
        if (!isWindowActive) return
        
        isWindowActive = false
        undoState = null
        listener.onUndoTimedOut()
        listener.onUndoWindowClosed()
    }
    
    fun isActive() = isWindowActive
    
    fun getCurrentState() = undoState
    
    fun cleanup() {
        timeoutRunnable?.let { handler.removeCallbacks(it) }
        timeoutRunnable = null
        undoState = null
        isWindowActive = false
    }
}
